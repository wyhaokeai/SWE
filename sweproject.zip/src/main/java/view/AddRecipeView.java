package view;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class AddRecipeView extends Application {
    private ImageView imageView;
    private TextArea recipeNameArea;

    @Override
    public void start(Stage primaryStage) {
        // Create the root pane
        AnchorPane root = new AnchorPane();

        // Set the background image
        setBackground(root);

        // Add components
        setRecipeNameArea(root);
        setServeAmount(root);
        setImageView(root, primaryStage);
        setIngredients(root);
        setSteps(root);
        setActionButtons(root, primaryStage);

        // Create the scene and set the stage
        Scene scene = new Scene(root, 1200, 600);
        primaryStage.setTitle("AddRecipeView");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void setBackground(AnchorPane root) {
        Image backgroundImage = new Image(getClass().getResource("/background.jpg").toExternalForm());
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        root.setBackground(new Background(background));
    }

    private void setRecipeNameArea(AnchorPane root) {
        recipeNameArea = new TextArea();
        recipeNameArea.setPromptText("Enter the recipe name");
        recipeNameArea.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        recipeNameArea.setPrefWidth(200); // Set preferred width
        recipeNameArea.setPrefHeight(150);
        recipeNameArea.setWrapText(true); // Enable text wrapping
        AnchorPane.setTopAnchor(recipeNameArea, 40.0);
        AnchorPane.setLeftAnchor(recipeNameArea, 70.0);
        root.getChildren().add(recipeNameArea);
    }

    private void setServeAmount(AnchorPane root) {
        Label serveAmountLabel = new Label("Serve amount:");
        serveAmountLabel.setStyle("-fx-font-size: 20px;-fx-font-weight: bold;");
        TextField serveAmountField = new TextField("1");
        serveAmountField.setEditable(false);
        serveAmountField.setPrefWidth(150);
        AnchorPane.setTopAnchor(serveAmountLabel, 200.0);
        AnchorPane.setLeftAnchor(serveAmountLabel, 70.0);
        AnchorPane.setTopAnchor(serveAmountField, 230.0);
        AnchorPane.setLeftAnchor(serveAmountField, 70.0);
        root.getChildren().addAll(serveAmountLabel, serveAmountField);
    }

    private void setImageView(AnchorPane root, Stage primaryStage) {
        Image defaultImage = new Image(getClass().getResourceAsStream("/upload.jpg"));
        imageView = new ImageView(defaultImage);
        imageView.setFitWidth(200);
        imageView.setFitHeight(200);
        imageView.setStyle("-fx-border-color: black;");
        imageView.setOnMouseClicked(event -> uploadImage(primaryStage));
        AnchorPane.setTopAnchor(imageView, 300.0);
        AnchorPane.setLeftAnchor(imageView, 70.0);
        root.getChildren().add(imageView);

        // Add text below the image
        Label clickToChangeLabel = new Label("*click the picture to upload");
        clickToChangeLabel.setStyle("-fx-font-size: 12px;");
        AnchorPane.setTopAnchor(clickToChangeLabel, 510.0);
        AnchorPane.setLeftAnchor(clickToChangeLabel, 70.0);
        root.getChildren().add(clickToChangeLabel);
    }

    private void uploadImage(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        File selectedFile = fileChooser.showOpenDialog(stage);
        if (selectedFile != null) {
            try {
                Image image = new Image(new FileInputStream(selectedFile));
                imageView.setImage(image);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void setIngredients(AnchorPane root) {
        Label ingredientsLabel = new Label("Ingredients:");
        ingredientsLabel.setStyle("-fx-font-size: 20px;-fx-font-weight: bold;");
        TextArea ingredientsArea = new TextArea();
        ingredientsArea.setPromptText("Click the button to add ingredients");
        ingredientsArea.setEditable(true);
        ingredientsArea.setPrefWidth(350);
        ingredientsArea.setPrefHeight(430);
        AnchorPane.setTopAnchor(ingredientsLabel, 40.0);
        AnchorPane.setLeftAnchor(ingredientsLabel, 350.0);
        AnchorPane.setTopAnchor(ingredientsArea, 70.0);
        AnchorPane.setLeftAnchor(ingredientsArea, 350.0);
        root.getChildren().addAll(ingredientsLabel, ingredientsArea);

        // Add "Add ingredients" button below ingredientsArea
        Button addIngredientsButton = new Button("Add ingredients");
        AnchorPane.setTopAnchor(addIngredientsButton, 520.0);
        AnchorPane.setLeftAnchor(addIngredientsButton, 350.0);
        root.getChildren().add(addIngredientsButton);
    }

    private void setSteps(AnchorPane root) {
        Label stepsLabel = new Label("Steps:");
        stepsLabel.setStyle("-fx-font-size: 20px;-fx-font-weight: bold;");
        TextArea stepsArea = new TextArea();
        stepsArea.setPromptText("Enter the steps");
        stepsArea.setEditable(true);
        stepsArea.setPrefWidth(350);
        stepsArea.setPrefHeight(430);
        AnchorPane.setTopAnchor(stepsLabel, 40.0);
        AnchorPane.setLeftAnchor(stepsLabel, 760.0);
        AnchorPane.setTopAnchor(stepsArea, 70.0);
        AnchorPane.setLeftAnchor(stepsArea, 760.0);
        root.getChildren().addAll(stepsLabel, stepsArea);
    }

    private void setActionButtons(AnchorPane root, Stage primaryStage) {
        // Add "Save recipe" button
        Button saveRecipeButton = new Button("Save recipe");
        saveRecipeButton.setOnAction(event -> showConfirmationDialog(primaryStage, "Are you sure to save the recipe and go back to the home page?", true));
        AnchorPane.setBottomAnchor(saveRecipeButton, 30.0);
        AnchorPane.setRightAnchor(saveRecipeButton, 100.0); // Move to the left
        root.getChildren().add(saveRecipeButton);

        // Add "Back" button
        Button backButton = new Button("Back");
        backButton.setOnAction(event -> showConfirmationDialog(primaryStage, "You haven't saved the changes, are you sure to go back to home page?", false));
        AnchorPane.setBottomAnchor(backButton, 30.0);
        AnchorPane.setRightAnchor(backButton, 30.0); // Position to the right of "Save recipe"
        root.getChildren().add(backButton);
    }

    private void showConfirmationDialog(Stage primaryStage, String message, boolean isSave) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText(message);

        ButtonType buttonYes = new ButtonType("Yes");
        ButtonType buttonNo = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(buttonYes, buttonNo);

        alert.showAndWait().ifPresent(response -> {
            if (response == buttonYes) {
                primaryStage.close();
                MainPageView mainPageView = new MainPageView();
                Stage newStage = new Stage();
                mainPageView.start(newStage);
            } else {
                alert.close();
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
