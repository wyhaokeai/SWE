package view;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.stage.Stage;

public class RecipePageView extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Create the root pane
        AnchorPane root = new AnchorPane();

        // Set the background image
        setBackground(root);

        // Add components
        setRecipeNameLabel(root);
        setServeAmount(root);
        setImageView(root);
        setIngredients(root);
        setSteps(root);
        setManageRecipeButton(root, primaryStage);
        setBackButton(root, primaryStage); // Add the back button

        // Create the scene and set the stage
        Scene scene = new Scene(root, 1200, 600);
        primaryStage.setTitle("RecipePageView");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void setBackground(AnchorPane root) {
        Image backgroundImage = new Image(getClass().getResource("/background.jpg").toExternalForm());
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        root.setBackground(new Background(background));
    }

    private void setRecipeNameLabel(AnchorPane root) {
        Label recipeNameLabel = new Label("Recipe\nNAME");
        recipeNameLabel.setStyle("-fx-font-size: 40px; -fx-font-weight: bold;");
        AnchorPane.setTopAnchor(recipeNameLabel, 40.0);
        AnchorPane.setLeftAnchor(recipeNameLabel, 70.0);
        root.getChildren().add(recipeNameLabel);
    }

    private void setServeAmount(AnchorPane root) {
        Label serveAmountLabel = new Label("Serve amount:");
        serveAmountLabel.setStyle("-fx-font-size: 20px;-fx-font-weight: bold;");
        TextField serveAmountField = new TextField();
        serveAmountField.setPrefWidth(150);
        AnchorPane.setTopAnchor(serveAmountLabel, 200.0);
        AnchorPane.setLeftAnchor(serveAmountLabel, 70.0);
        AnchorPane.setTopAnchor(serveAmountField, 230.0);
        AnchorPane.setLeftAnchor(serveAmountField, 70.0);
        root.getChildren().addAll(serveAmountLabel, serveAmountField);
    }

    private void setImageView(AnchorPane root) {
        Image hongshaorouImage = new Image(getClass().getResourceAsStream("/hongshaorou.jpg"));
        ImageView imageView = new ImageView(hongshaorouImage);
        imageView.setFitWidth(200);
        imageView.setFitHeight(200);
        imageView.setStyle("-fx-border-color: black;");
        AnchorPane.setTopAnchor(imageView, 300.0);
        AnchorPane.setLeftAnchor(imageView, 70.0);
        root.getChildren().add(imageView);
    }

    private void setIngredients(AnchorPane root) {
        Label ingredientsLabel = new Label("Ingredients:");
        ingredientsLabel.setStyle("-fx-font-size: 20px;-fx-font-weight: bold;");
        TextArea ingredientsArea = new TextArea("blank");
        ingredientsArea.setEditable(false);
        ingredientsArea.setPrefWidth(350);
        ingredientsArea.setPrefHeight(430);
        AnchorPane.setTopAnchor(ingredientsLabel, 40.0);
        AnchorPane.setLeftAnchor(ingredientsLabel, 350.0);
        AnchorPane.setTopAnchor(ingredientsArea, 70.0);
        AnchorPane.setLeftAnchor(ingredientsArea, 350.0);
        root.getChildren().addAll(ingredientsLabel, ingredientsArea);
    }

    private void setSteps(AnchorPane root) {
        Label stepsLabel = new Label("Steps:");
        stepsLabel.setStyle("-fx-font-size: 20px;-fx-font-weight: bold;");
        TextArea stepsArea = new TextArea("blank");
        stepsArea.setEditable(false);
        stepsArea.setPrefWidth(350);
        stepsArea.setPrefHeight(430);
        AnchorPane.setTopAnchor(stepsLabel, 40.0);
        AnchorPane.setLeftAnchor(stepsLabel, 760.0);
        AnchorPane.setTopAnchor(stepsArea, 70.0);
        AnchorPane.setLeftAnchor(stepsArea, 760.0);
        root.getChildren().addAll(stepsLabel, stepsArea);
    }

    private void setManageRecipeButton(AnchorPane root, Stage primaryStage) {
        Button manageRecipeButton = new Button("Manage recipe");
        AnchorPane.setBottomAnchor(manageRecipeButton, 30.0);
        AnchorPane.setRightAnchor(manageRecipeButton, 90.0); // Move the button slightly to the left
        manageRecipeButton.setOnAction(event -> {
            primaryStage.close();
            ManageRecipeView manageRecipeView = new ManageRecipeView();
            Stage newStage = new Stage();
            manageRecipeView.start(newStage);
        });
        root.getChildren().add(manageRecipeButton);
    }

    private void setBackButton(AnchorPane root, Stage primaryStage) {
        Button backButton = new Button("Back");
        AnchorPane.setBottomAnchor(backButton, 30.0);
        AnchorPane.setRightAnchor(backButton, 30.0); // Position the button to the right of "Manage recipe"
        backButton.setOnAction(event -> {
            primaryStage.close();
            MainPageView mainPageView = new MainPageView();
            Stage newStage = new Stage();
            mainPageView.start(newStage);
        });
        root.getChildren().add(backButton);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
