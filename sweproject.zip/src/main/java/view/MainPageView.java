package view;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Model;
import model.Recipe;

import java.util.List;

public class MainPageView extends Application {

    private Model model = new Model();
    private Pane contentPane;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Recipe");

        // Create the main layout
        AnchorPane mainLayout = new AnchorPane();
        setBackgroundImage(mainLayout);

        // Set up components
        setLanguageSelection(mainLayout);
        setModeSelection(mainLayout);
        setTitle(mainLayout);
        setSearchBox(mainLayout);
        setScrollableContent(mainLayout);
        setAddRecipeButton(mainLayout, primaryStage);

        // Load all recipes initially
        loadRecipes(model.getAllRecipes());

        // Set up the scene and stage
        Scene scene = new Scene(mainLayout, 1200, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void setBackgroundImage(AnchorPane mainLayout) {
        Image backgroundImage = new Image(getClass().getResource("/background.jpg").toExternalForm());
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        mainLayout.setBackground(new Background(background));
    }

    private void setLanguageSelection(AnchorPane mainLayout) {
        Label languageLabel = new Label("Language:");
        languageLabel.setStyle("-fx-font-weight: bold;");
        ComboBox<String> languageComboBox = new ComboBox<>();
        languageComboBox.getItems().addAll("简体中文", "English");
        languageComboBox.setPrefWidth(100);
        languageComboBox.setPrefHeight(25);
        AnchorPane.setTopAnchor(languageLabel, 15.0);
        AnchorPane.setRightAnchor(languageLabel, 115.0);
        AnchorPane.setTopAnchor(languageComboBox, 10.0);
        AnchorPane.setRightAnchor(languageComboBox, 10.0);

        mainLayout.getChildren().addAll(languageLabel, languageComboBox);
    }

    private void setModeSelection(AnchorPane mainLayout) {
        Label modeLabel = new Label("Mode:");
        modeLabel.setStyle("-fx-font-weight: bold;");
        ComboBox<String> modeComboBox = new ComboBox<>();
        modeComboBox.getItems().addAll("Day", "Night");
        modeComboBox.setPrefWidth(100);
        modeComboBox.setPrefHeight(25);
        AnchorPane.setTopAnchor(modeLabel, 45.0);
        AnchorPane.setRightAnchor(modeLabel, 115.0);
        AnchorPane.setTopAnchor(modeComboBox, 40.0);
        AnchorPane.setRightAnchor(modeComboBox, 10.0);

        mainLayout.getChildren().addAll(modeLabel, modeComboBox);
    }

    private void setTitle(AnchorPane mainLayout) {
        Label titleLabel = new Label("Recipe");
        titleLabel.setStyle("-fx-font-size: 48px; -fx-font-family: 'Bahnschrift SemiBold Condensed'; -fx-font-weight: bold;-fx-letter-spacing: 0.08em;");
        AnchorPane.setTopAnchor(titleLabel, 100.0);
        AnchorPane.setLeftAnchor(titleLabel, 520.0);

        mainLayout.getChildren().add(titleLabel);
    }

    private void setSearchBox(AnchorPane mainLayout) {
        TextField searchBox = new TextField();
        searchBox.setPromptText("Enter to search recipe");
        searchBox.setPrefWidth(300);
        searchBox.setPrefHeight(30);
        AnchorPane.setTopAnchor(searchBox, 200.0);
        double leftMarginSearchBox = (1200 - searchBox.getPrefWidth()) / 2;
        AnchorPane.setLeftAnchor(searchBox, leftMarginSearchBox);

        searchBox.setOnAction(event -> {
            String searchTerm = searchBox.getText();
            if (searchTerm.isEmpty()) {
                loadRecipes(model.getAllRecipes());
            } else {
                loadRecipes(model.searchRecipes(searchTerm));
            }
        });

        mainLayout.getChildren().add(searchBox);
    }

    private void setScrollableContent(AnchorPane mainLayout) {
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setPrefHeight(200);
        contentPane = new Pane();
        scrollPane.setContent(contentPane);
        AnchorPane.setTopAnchor(scrollPane, 300.0);
        AnchorPane.setLeftAnchor(scrollPane, 10.0);
        AnchorPane.setRightAnchor(scrollPane, 10.0);

        mainLayout.getChildren().add(scrollPane);
    }

    private void loadRecipes(List<Recipe> recipes) {
        contentPane.getChildren().clear();
        double x = 10.0;
        double y = 10.0;
        double imageSize = 150.0;

        for (Recipe recipe : recipes) {
            ImageView imageView = new ImageView(new Image(recipe.getImgAddress()));
            imageView.setFitWidth(imageSize);
            imageView.setFitHeight(imageSize);

            Label nameLabel = new Label(recipe.getRecipeName());
            nameLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
            nameLabel.setPrefWidth(imageSize);
            nameLabel.setWrapText(true);

            VBox recipeBox = new VBox(imageView, nameLabel);
            recipeBox.setLayoutX(x);
            recipeBox.setLayoutY(y);
            recipeBox.setSpacing(5);

            contentPane.getChildren().add(recipeBox);

            x += imageSize + 20;
            if (x + imageSize > contentPane.getWidth()) {
                x = 10.0;
                y += imageSize + 40;
            }
        }
    }

    private void setAddRecipeButton(AnchorPane mainLayout, Stage primaryStage) {
        Button addRecipeButton = new Button("Add recipe");
        addRecipeButton.setOnAction(event -> {
            primaryStage.close();
            ManageRecipeView manageRecipeView = new ManageRecipeView();
            Stage newStage = new Stage();
            manageRecipeView.start(newStage);
        });
        AnchorPane.setBottomAnchor(addRecipeButton, 10.0);
        AnchorPane.setRightAnchor(addRecipeButton, 10.0);

        mainLayout.getChildren().add(addRecipeButton);
    }

    public static void main(String[] args) {
        launch(args);
    }
}

