// model/Ingredient.java
package model;

public class Ingredient {
    private int recipeId;
    private String ingredientName;
    private int amount;
    private String unit;

    // Constructor
    public Ingredient(int recipeId, String ingredientName, int amount, String unit) {
        this.recipeId = recipeId;
        this.ingredientName = ingredientName;
        this.amount = amount;
        this.unit = unit;
    }

    // Getter and Setter methods
    public int getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(int recipeId) {
        this.recipeId = recipeId;
    }

    public String getIngredientName() {
        return ingredientName;
    }

    public void setIngredientName(String ingredientName) {
        this.ingredientName = ingredientName;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    // Override toString method
    @Override
    public String toString() {
        return "Ingredient{" +
                "recipeId=" + recipeId +
                ", ingredientName='" + ingredientName + '\'' +
                ", amount=" + amount +
                ", unit='" + unit + '\'' +
                '}';
    }
}
