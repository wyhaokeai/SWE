// model/Recipe.java
package model;

public class Recipe {
    private int recipeId;
    private String recipeName;
    private String step;
    private String imgAddress;

    // Constructor
    public Recipe(int recipeId, String recipeName, String step, String imgAddress) {
        this.recipeId = recipeId;
        this.recipeName = recipeName;
        this.step = step;
        this.imgAddress = imgAddress;
    }

    // Getter and Setter methods
    public int getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(int recipeId) {
        this.recipeId = recipeId;
    }

    public String getRecipeName() {
        return recipeName;
    }

    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getImgAddress() {
        return imgAddress;
    }

    public void setImgAddress(String imgAddress) {
        this.imgAddress = imgAddress;
    }

    // Override toString method
    @Override
    public String toString() {
        return "Recipe{" +
                "recipeId=" + recipeId +
                ", recipeName='" + recipeName + '\'' +
                ", step='" + step + '\'' +
                ", imgAddress='" + imgAddress + '\'' +
                '}';
    }
}
