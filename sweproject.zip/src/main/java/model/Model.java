package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Model {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/cookbook?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "1127wy1106";

    public Connection connect() {
        Connection connection = null;
        try {
            // 显式加载驱动程序
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public List<Recipe> getAllRecipes() {
        List<Recipe> recipes = new ArrayList<>();
        String query = "SELECT * FROM recipe"; // 更新表名为 recipe

        try (Connection connection = connect();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                int recipeId = resultSet.getInt("recipeId");
                String recipeName = resultSet.getString("recipeName");
                String step = resultSet.getString("step");
                String imgAddress = resultSet.getString("imgAddress");
                recipes.add(new Recipe(recipeId, recipeName, step, imgAddress));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return recipes;
    }

    public List<Recipe> searchRecipes(String searchTerm) {
        List<Recipe> recipes = new ArrayList<>();
        String query = "SELECT * FROM recipe WHERE recipeName LIKE ?"; // 更新表名为 recipe

        try (Connection connection = connect();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, "%" + searchTerm + "%");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int recipeId = resultSet.getInt("recipeId");
                String recipeName = resultSet.getString("recipeName");
                String step = resultSet.getString("step");
                String imgAddress = resultSet.getString("imgAddress");
                recipes.add(new Recipe(recipeId, recipeName, step, imgAddress));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return recipes;
    }
}
