// main/Entrance.java
package main;

import model.Recipe;
import model.Ingredient;

public class Entrance {
    public static void main(String[] args) {
        // Create Recipe object
        Recipe recipe = new Recipe(1, "Braised Pork", "Step 1: Prepare ingredients\nStep 2: Cook the pork", "/images/braised_pork.jpg");

        // Create Ingredient object
        Ingredient ingredient = new Ingredient(1, "Pork", 500, "grams");

        // Output the objects
        System.out.println(recipe);
        System.out.println(ingredient);
    }
}
